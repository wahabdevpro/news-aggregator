// src/redux/store.js
import { configureStore } from "@reduxjs/toolkit";
import modalReducer from "./slices/modalSlice";
import alertReducer from "./slices/alertSlice";
// Add other slices as needed

export const store = configureStore({
  reducer: {
    modal: modalReducer,
    alert: alertReducer,
  },
});

export default store;
