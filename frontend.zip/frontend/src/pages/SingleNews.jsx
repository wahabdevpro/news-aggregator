import { Box, Typography, Avatar, Container, Grid, Link } from "@mui/material";
import PropTypes from "prop-types";
import { article, latestNews } from "../utils/dummy";

/**
 * A reusable component for displaying the content of a news article.
 *
 * This component expects the following properties:
 *  - article: An object containing the article data with the following properties:
 *    - image: The URL of the article image
 *    - headline: The article headline
 *    - author: The article author
 *    - date: The date the article was published
 *    - content: An array of strings, each representing a paragraph of the article content
 *
 * @param {{ article: { image: string, headline: string, author: string, date: string, content: string[] } }} props
 * @returns {React.ReactElement} A React element representing the rendered news article content
 */
const NewsContent = ({ article }) => (
  <Box>
    {/* Display the article image */}
    <Box
      component="img"
      src={article.image}
      alt={article.headline}
      sx={{ width: "100%", height: "auto", mb: 2 }}
    />

    {/* Display the article headline */}
    <Typography variant="h4" component="h1" gutterBottom>
      {article.headline}
    </Typography>

    {/* Display the article author and metadata */}
    <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
      <Avatar sx={{ width: 32, height: 32 }} />
      <Typography variant="body1" sx={{ ml: 2 }}>
        By {article.author} | Published on {article.date}
      </Typography>
    </Box>

    {/* Display the article content */}
    {article.content.map((paragraph, index) => (
      <Typography key={index} variant="body1" paragraph>
        {paragraph}
      </Typography>
    ))}
  </Box>
);

// PropTypes for NewsContent
NewsContent.propTypes = {
  article: PropTypes.shape({
    image: PropTypes.string.isRequired,
    headline: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired,
    date: PropTypes.string.isRequired,
    content: PropTypes.arrayOf(PropTypes.string).isRequired,
  }).isRequired,
};

// Reusable Component for displaying latest news or blogs in the sidebar
const LatestNews = ({ newsItems }) => (
  <Box sx={{ padding: 2, backgroundColor: "whitesmoke" }}>
    <Typography variant="h6" gutterBottom>
      Latest News
    </Typography>
    {newsItems.map((newsItem, index) => (
      <Box key={index} sx={{ mb: 2 }}>
        <Typography variant="body1">{newsItem}</Typography>
        <Link href="#" variant="body2" color="primary">
          Read now →
        </Link>
      </Box>
    ))}
  </Box>
);

// PropTypes for LatestNews
LatestNews.propTypes = {
  newsItems: PropTypes.arrayOf(PropTypes.string).isRequired,
};

/**
 * SingleNewsPage component that displays the details of a single news article
 * and a sidebar for latest news.
 *
 * @component
 */
const SingleNewsPage = () => {
  // Mock data for the news article

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Grid container spacing={4}>
        {/* Main Article Section */}
        <Grid item xs={12} md={8}>
          <NewsContent article={article} />
        </Grid>

        {/* Sidebar for Latest News */}
        <Grid item xs={12} md={4}>
          <LatestNews newsItems={latestNews} />
        </Grid>
      </Grid>
    </Container>
  );
};

export default SingleNewsPage;
