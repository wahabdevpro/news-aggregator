import { Box, Container, Grid} from "@mui/material";
import { useState } from "react";
import { useNavigate } from "react-router-dom"; 
import CategoryNavbar from "../components/pages/feed/CategoryNavbar";
import ArticleCard from "../components/global/ArticleCard";


import { articles, categories, } from "../utils/dummy";
import PaginationComponent from "../components/global/Pagination";

/**
 * Function to get the articles for a given page.
 *
 * @param {Array} articles - The list of all articles.
 * @param {number} currentPage - The current page number.
 * @param {number} articlesPerPage - Number of articles to display per page.
 * @returns {Array} - The articles for the current page.
 */
const getArticlesForPage = (articles, currentPage, articlesPerPage) => {
  const indexOfLastArticle = currentPage * articlesPerPage;
  const indexOfFirstArticle = indexOfLastArticle - articlesPerPage;
  return articles.slice(indexOfFirstArticle, indexOfLastArticle);
};

/**
 * FeedPage component that displays a grid of articles with pagination.
 *
 * This component displays a grid of articles based on the current page and
 * allows the user to navigate between pages using the pagination component.
 *
 * @component
 */
const FeedPage = () => {
  // Mock data for articles
  const navigate = useNavigate(); // Initialize useNavigate from React Router

  // State for pagination
  const [currentPage, setCurrentPage] = useState(1);
  const articlesPerPage = 4; // Display 4 articles per page

  // Get the current articles for the current page using the helper function
  const currentArticles = getArticlesForPage(articles, currentPage, articlesPerPage);



  // Change page
  /**
   * Handles the change of the page by setting the current page to the
   * new value.
   *
   * @param {Object} event - The event object.
   * @param {number} value - The new page number.
   */
  const handleChangePage = ( value) => {
    setCurrentPage(value);
  };

  // Handle category selection
  /**
   * Handles the selection of a category by logging the selected category
   * to the console.
   *
   * @param {Object} category - The selected category object.
   */
  const handleCategorySelect = (category) => {
    console.log("Selected Category:", category);
    // Add your logic to fetch/filter content based on the selected category
  };

  // Handle article click to navigate to the news/:id route
  /**
   * Handles the click on an article by navigating to the news/:id route.
   *
   * @param {number} id - The article ID.
   */
  const handleArticleClick = (id) => {
    navigate(`/news/${id}`);
  };

  return (
    <Box sx={{ maxWidth: "100%", margin: 'auto auto' }}>
   

      {/* Category Navbar */}
      <CategoryNavbar
        categories={categories}
        onCategorySelect={handleCategorySelect}
      />

      {/* Main Content */}
      <Container maxWidth="xl" sx={{ py: 4, }}>
        <Grid container spacing={3}>
          {/* Main Articles Section */}
          {currentArticles.map((article, index) => (
            <Grid
              item
              xs={12} // 1 item per row on extra-small devices (<600px)
              sm={6} // 2 items per row on small devices (600px+)
              md={4} // 3 items per row on medium devices (900px+)
              lg={3} // 4 items per row on large devices (1200px+)
              key={index}
              onClick={() => handleArticleClick(article.id)} // Navigate on article click
              sx={{ cursor: "pointer" }} // Add a pointer cursor to indicate clickability
            >
              <ArticleCard article={article} />
            </Grid>
          ))}
        </Grid>

        {/* Pagination */}
        {/* <Stack spacing={2} sx={{ mt: 4 }} alignItems="center">
          <Pagination
            count={Math.ceil(articles.length / articlesPerPage)} // Total number of pages
            page={currentPage}
            onChange={handleChangePage}
            color="primary"
          />
        </Stack> */}
        <PaginationComponent
        totalItems={articles.length}
        itemsPerPage={articlesPerPage}
        currentPage={currentPage}
        onPageChange={handleChangePage}
      />
      </Container>
    </Box>
  );
};

export default FeedPage;
