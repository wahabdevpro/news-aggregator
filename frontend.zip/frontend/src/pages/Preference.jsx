import { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Grid,
  Paper,
} from "@mui/material";
import Btn from "../components/global/Button";
import CheckboxGroup from "../components/global/CheckBoxGroup";

/**
 * Preferences component to allow users to select their preferred categories and sources.
 * The component handles user input and saves selected preferences.
 *
 * The data includes mock categories, sources, and user preferences.
 *
 * @component
 * @returns {JSX.Element} The Preferences component.
 */
const Preferences = () => {
  // Mock data simulating the backend response
  const data = {
    success: true,
    data: {
      categories: {
        business: { id: "business", label: "Business" },
        entertainment: { id: "entertainment", label: "Entertainment" },
        general: { id: "general", label: "General" },
        health: { id: "health", label: "Health" },
        science: { id: "science", label: "Science" },
        sports: { id: "sports", label: "Sports" },
        technology: { id: "technology", label: "Technology" },
      },
      sources: {
        newsapi: { id: "newsapi", label: "NewsAPI" },
        guardian: { id: "guardian", label: "The Guardian" },
        nytimes: { id: "nytimes", label: "The New York Times" },
      },
      userPreferences: {
        categories: [
          { id: "business", label: "Business" },
          { id: "health", label: "Health" },
        ],
        sources: [{ id: "newsapi", label: "NewsAPI" }],
      },
    },
  };

  // State to track selected categories and sources
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedSources, setSelectedSources] = useState([]);

  // Initialize categories and sources based on user preferences
  useEffect(() => {
    setSelectedCategories(
      data.data.userPreferences.categories.map((category) => category.id)
    );
    setSelectedSources(
      data.data.userPreferences.sources.map((source) => source.id)
    );
  }, []);

  /**
   * Handles the selection of categories and updates the state.
   *
   * @param {string} id - The id of the selected category.
   */
  const handleCategoryChange = (id) => {
    setSelectedCategories((prevSelected) =>
      prevSelected.includes(id)
        ? prevSelected.filter((categoryId) => categoryId !== id)
        : [...prevSelected, id]
    );
  };

  /**
   * Handles the selection of sources and updates the state.
   *
   * @param {string} id - The id of the selected source.
   */
  const handleSourceChange = (id) => {
    setSelectedSources((prevSelected) =>
      prevSelected.includes(id)
        ? prevSelected.filter((sourceId) => sourceId !== id)
        : [...prevSelected, id]
    );
  };

  /**
   * Handle the form submission to save preferences.
   */
  const handleSubmit = () => {
    const preferences = {
      categories: selectedCategories,
      sources: selectedSources,
    };
    console.log("Saved Preferences:", preferences);
    // Later: Call the API to save preferences
  };



  return (
    <Box sx={{ width: "100%", mt: 4 }}>
      <Grid container spacing={3} justifyContent="center">
        <Grid item xs={12} sm={10} md={8} lg={6}>
          <Paper sx={{ p: 4, borderRadius: 2 }}>
            <Typography variant="h5" align="center" gutterBottom>
              Choose Your Preferences
            </Typography>

            <Grid container spacing={3}>
              {/* Categories Section */}
              <Grid item xs={12} sm={6}>
                <Typography variant="h6" gutterBottom>
                  Categories
                </Typography>
                  <CheckboxGroup
                  items={Object.values(data.data.categories)}
                  selectedItems={selectedCategories}
                  onItemChange={handleCategoryChange}
                />
              </Grid>

              {/* Sources Section */}
              <Grid item xs={12} sm={6}>
                <Typography variant="h6" gutterBottom>
                  Sources
                </Typography>

                <CheckboxGroup
                  items={Object.values(data.data.sources)}
                  selectedItems={selectedSources}
                  onItemChange={handleSourceChange}
                />
              </Grid>
            </Grid>

            {/* Save Preferences Button */}
            <Box display="flex" justifyContent="center" mt={4}>
              <Btn
                text="Save Preferences"
                onClick={handleSubmit}
                key={"btn"}
                fullWidth={false} // Disable full width
                sx={{ minWidth: 150 }} // Optional: Control the minimum width
              />
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Preferences;
