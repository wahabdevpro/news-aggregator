import { Helper } from "./helper";

// APIService.js
export class APIService {
  constructor(baseURL) {
    this.baseURL = baseURL; // Set the base URL for the API
  }

  async request(method, endpoint, data = null, headers = {}) {
    try {
      const options = {
        method,
        headers: {
          ...headers,
          "Content-Type": "application/json",
        },
      };

      if (data) options.body = JSON.stringify(data);
      console.log(options);
      const response = await fetch(`${this.baseURL}${endpoint}`, options);
      const responseData = await response.json();
      console.log(`API Response: ${JSON.stringify(responseData)}`);

      return response.ok
        ? responseData
        : Helper.returnObj(false, `HTTP error! Status: ${response.status}`);
    } catch (error) {
      return Helper.returnObj(false, error.message);
    }
  }
}

// AuthService.js (Specific Service for Authentication)
export class AuthService {
  constructor(apiService) {
    this.apiService = apiService;
  }

  login(data) {
    return this.apiService.request("POST", "login", data);
  }

  register(data) {
    return this.apiService.request("POST", "register", data);
  }
}

// NewsService.js (Specific Service for News API)
export class NewsService {
  constructor(apiService) {
    this.apiService = apiService;
  }

  getNews(params = {}) {
    // Assume params are used for filtering news
    const queryString = new URLSearchParams(params).toString();
    return this.apiService.request("GET", `/news?${queryString}`);
  }
}

// Main API Client
const baseURL = "http://192.168.1.3:8000/api/";
const apiService = new APIService(baseURL);

// Expose all the services
export const services = {
  auth: new AuthService(apiService),
  news: new NewsService(apiService),
};

// Usage Example in a Component or Hook
// import { services } from './APIClient';

// const response = await services.auth.login({ email, password });
// if (response.success) {
//   // Handle success
// } else {
//   // Handle error
// }
