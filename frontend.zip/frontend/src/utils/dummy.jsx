export const filterData = {
    categories: {
      business: { id: "business", label: "Business" },
      entertainment: { id: "entertainment", label: "Entertainment" },
      health: { id: "health", label: "Health" },
      science: { id: "science", label: "Science" },
    },
    sources: {
      bbc: { id: "bbc", label: "BBC" },
      cnn: { id: "cnn", label: "CNN" },
      guardian: { id: "guardian", label: "The Guardian" },
      nytimes: { id: "nytimes", label: "New York Times" },
    },
  };

  export const handleFilterSubmit = (filters) => {
    console.log("Applied Filters:", filters);
    // Perform the news filtering logic or API call here
  };



 export const articles = [
    {
      image: "https://via.placeholder.com/300x200",
      title: "Making wearable medical devices more patient-friendly",
      author: "Darrell Etherington",
      date: "October 4, 2023",
      id: 1,
    },
    {
      image: "https://via.placeholder.com/300x200",
      title: "Rainforest raises $8.5M to help companies",
      author: "Mary Ann Azevedo",
      date: "October 1, 2023",
      id: 2,
    },
    {
      image: "https://via.placeholder.com/300x200",
      title: "Pow.bio says biomanufacturing is broken",
      author: "Christine Hall",
      date: "October 1, 2023",
      id: 3,
    },
    {
      image: "https://via.placeholder.com/300x200",
      title: "Another Article",
      author: "Jane Doe",
      date: "October 5, 2023",
      id: 4,
    },
    {
      image: "https://via.placeholder.com/300x200",
      title: "Making wearable medical devices more patient-friendly",
      author: "Darrell Etherington",
      date: "October 4, 2023",
      id: 5,
    },
    {
      image: "https://via.placeholder.com/300x200",
      title: "Rainforest raises $8.5M to help companies",
      author: "Mary Ann Azevedo",
      date: "October 1, 2023",
      id: 6,
    },
    {
      image: "https://via.placeholder.com/300x200",
      title: "Pow.bio says biomanufacturing is broken",
      author: "Christine Hall",
      date: "October 1, 2023",
      id: 7,
    },
    {
      image: "https://via.placeholder.com/300x200",
      title: "Another Article",
      author: "Jane Doe",
      date: "October 5, 2023",
      id: 8,
    },
  ];

 export const categories = [
    { id: 1, label: "All" },
    { id: 2, label: "Startups" },
    { id: 3, label: "Security" },
    { id: 4, label: "AI" },
    { id: 5, label: "Apps" },
    { id: 6, label: "Tech" },
    { id: 7, label: "More" },
  ];







  // Single post 
 export const article = {
    image: "https://via.placeholder.com/800x400",
    headline: "Making wearable medical devices more patient-friendly",
    author: "Darrell Etherington",
    date: "October 4, 2023",
    content: [
      "In a world where healthcare technology is constantly evolving, one company is making strides to ensure that patients receive better care. Acurlable, a leading company in wearable technology, has partnered with Professor Esther Rodriguez-Villegas to make medical devices more patient-friendly.",
      "The new medical device, designed to monitor a patient's vitals remotely, promises to revolutionize patient care by offering a more comfortable and user-friendly experience.",
      "As healthcare becomes increasingly digital, the focus on patient comfort is more important than ever. Acurlable's innovations show how technology and care can work together to improve outcomes.",
    ],
  };

  // Mock data for the latest news in the sidebar
 export const latestNews = [
    "Making wearable medical devices more patient-friendly",
    "Rainforest raises $8.5M to help software companies",
    "Pow.bio says biomanufacturing is broken",
    "Recapitalization, $60M Series D support growth of e-commerce financier Clearco",
    "Rabbit is building an AI model that understands how software works",
  ];