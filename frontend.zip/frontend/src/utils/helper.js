/**
 * Helper object that contains validators and API utility functions.
 *
 * @type {Helper}
 */
export const Helper = {
  validators: {
    name: (name) => /^[a-zA-Z\s]{2,}$/.test(name),
    email: (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),
    password: (password) =>
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(
        password
      ),
  },
  returnObj: (success, data) => {
    return {
      success,
      data,
    };
  },
 // Local Storage Helper - separated from the main helper object
 localStorage: {
  setItem: (key, value) => {
    console.log(key, value)
    try {
      const data = typeof value === "string" ? value : JSON.stringify(value);
      localStorage.setItem(key, data);
      return Helper.returnObj(true, null); // Return success status and the stored data
    } catch (error) {
      console.error("Error saving to localStorage:", error);
      return Helper.returnObj(false, error.message); // Return error message
    }
  },
  getItem: (key) => {
    try {
      const data = localStorage.getItem(key);
      const parsedData = data ? JSON.parse(data) : null;
      return Helper.returnObj(true, parsedData); // Return success status and the data
    } catch (error) {
      console.error("Error reading from localStorage:", error);
      return Helper.returnObj(false, error.message); // Return error message
    }
  },
  removeItem: (key) => {
    try {
      localStorage.removeItem(key);
      return Helper.returnObj(true, `${key} removed`); // Return success status and the key that was removed
    } catch (error) {
      console.error("Error removing from localStorage:", error);
      return Helper.returnObj(false, error.message); // Return error message
    }
  },
 
},
isUserLoggedIn: () => {
  const token = Helper.localStorage.getItem("token");
  const user = Helper.localStorage.getItem("user");

  return token.success && token.data && user.success && user.data ? true : false;
},
logoutUser: () => {
  const removeToken = Helper.localStorage.removeItem("token");
  const removeUser = Helper.localStorage.removeItem("user");

  if (removeToken.success && removeUser.success) {
    return Helper.returnObj(true, "User logged out successfully");
  } else {
    return Helper.returnObj(false, "Error logging out");
  }
},
};
// JsDocs for the Helper object
/**
 * @typedef {Object} Helper
 * @property {Object} validators - An object containing validation functions for common fields.
 * @property {function(string): boolean} validators.name - Validates a name field to ensure it contains only letters and spaces, and is at least 2 characters long.
 * @property {function(string): boolean} validators.email - Validates an email field to ensure it follows a standard email format.
 * @property {function(string): boolean} validators.password - Validates a password field to ensure it meets complexity requirements.
 * @property {function(boolean, any): {success: boolean, data: any}} returnObj - Returns a standardized response object with success and data fields.
 * @property {Object} localStorage - A separated object containing local storage functions.
 * @property {function(string, any): {success: boolean, data: any}} localStorage.setItem - Saves data to local storage and returns success status.
 * @property {function(string): {success: boolean, data: any}} localStorage.getItem - Retrieves data from local storage and returns success status.
 * @property {function(string): {success: boolean, data: string}} localStorage.removeItem - Removes data from local storage and returns success status.
 * @property {function(): boolean} isUserLoggedIn - Checks if both the user and token are present in localStorage.
 * @property {function(): {success: boolean, data: string}} logoutUser - Logs out the user and returns a success status with a message.
 */
