import { Route, Routes } from "react-router-dom";
import AuthPage from "./pages/Auth";
import { Box } from "@mui/material";
import Footer from "./components/global/Footer";
import Header from "./components/global/Header";
// import FeedPage from "./pages/Feed";
import HomePage from "./pages/Home";
import SinglePostPage from "./pages/SingleNews";
import NotFoundPage from "./components/global/NotFound";
import PreferencesPage from "./pages/Preference";
import { lazy, Suspense } from "react";
import Loading from "./components/global/Loading";
import Alert from './components/global/Alert';

const FeedPage = lazy(() => import("./pages/Feed"));
const App = () => {
  return (
    <Box
      sx={{
        width: "100%",
        maxWidth: "1600px",
        margin: "0 auto",
        height: "auto",
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        overflowX: "hidden",
      }}
    >
      <Header />
      <Suspense fallback={<Loading />}>
      <Alert /> 
        <Routes>
          <Route path="/" exact element={<HomePage />} />
          <Route path="/articles" exact element={<FeedPage />} />
          <Route path="/auth/*" exact element={<AuthPage />} />
          <Route path="/news/:id" exact element={<SinglePostPage />} />
          <Route path="/preferences" exact element={<PreferencesPage />} />
          {/* <Route path="/filter" exact element={<FilterPage />} /> */}
          <Route path="*" exact element={<NotFoundPage />} />
        </Routes>
      </Suspense>
      <Footer />
    </Box>
  );
};

export default App;
