import { useState, memo } from "react";
import { Tabs, Tab, Box } from "@mui/material";
import PropTypes from "prop-types";

/**
 * A reusable tab component for displaying categories in the navbar.
 *
 * This component takes a list of category objects and renders them as tabs.
 * When a tab is selected, it invokes the provided callback function with the
 * selected category object.
 *
 * @param {Object} props - Component props.
 * @param {Array<Category>} props.categories - The list of category objects to display as tabs.
 * @param {function(Category): void} props.onCategorySelect - Callback function invoked when a category is selected.
 * @returns {JSX.Element} - The CategoryNavbar component.
 */
const CategoryNavbar = ({ categories, onCategorySelect }) => {
  const [selectedIndex, setSelectedIndex] = useState(0);

  /**
   * Handles changes to the selected tab index.
   *
   * @param {Object} _event - Synthetic event object (not used).
   * @param {number} newIndex - The new index of the selected tab.
   */
  const handleChange = (_event, newIndex) => {
    setSelectedIndex(newIndex);
    onCategorySelect(categories[newIndex]);
  };

  return (
    <Box
      sx={{
        // Styling for the tab bar
        borderBottom: 1,
        borderColor: "divider",
        backgroundColor: "white",
      }}
    >
      <Tabs
        value={selectedIndex}
        // Update the selected tab index when the user changes the tab
        onChange={handleChange}
        // Render the tabs in a scrollable container
        variant="scrollable"
        // Show auto-scrolling buttons when there are more tabs than can fit
        scrollButtons="auto"
        // Accessibility label for the tabs
        aria-label="category tabs"
      >
        {categories.map(({ id, label }) => (
          // Render each category as a tab
          <Tab key={id} label={label} />
        ))}
      </Tabs>
    </Box>
  );
};

// PropTypes for CategoryNavbar to ensure type safety and enforce required props
CategoryNavbar.propTypes = {
  categories: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired, 
      label: PropTypes.string.isRequired,
    })
  ).isRequired,
  onCategorySelect: PropTypes.func.isRequired, 
};

export default memo(CategoryNavbar);
