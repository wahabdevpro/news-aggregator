import { Box, Typography } from "@mui/material";
import PropTypes from "prop-types";
import Input from "../../global/Input";
import Btn from "../../global/Button";
import ActionLinkBtn from "../../global/ActionLinkBtn";
import { Helper } from "../../../utils/helper";
import { useForm } from "../../../utils/customHooks";
import { useDispatch } from "react-redux";
import { showAlert } from "../../../redux/slices/alertSlice";
import { services } from "../../../utils/API";
import { useNavigate } from "react-router-dom";

/**
 * Login component that renders a login form and handles form submission.
 *
 * This component allows users to log in by providing their email and password.
 * It handles form validation using the `useForm` hook and displays errors for invalid inputs.
 * Upon successful validation, it triggers the login process.
 *
 * @component
 * @param {function} setPage - Function to switch between login and signup pages.
 * @returns {JSX.Element} - The rendered login form component.
 */
const Login = ({ setPage }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { inputs, errors, handleChange, validate } = useForm(
    // Initial values for the login form
    { email: "", password: "" },
    // Validation rules for the login form
    {
      email: Helper.validators.email,
      password: Helper.validators.password,
    }
  );

  /**
   * Handles the registration form submission and displays an alert message
   * based on the validation result.
   */
  const handleSubmit = async () => {
    console.log(errors);
    const error = errors[Object.keys(errors)[0]];
    try {
      if (!validate()) {
        dispatch(
          showAlert({ message: error || "Invalid input", severity: "error" })
        );
      }

      // Call the AuthService to register the user
      const response = await services.auth.login({
        name: inputs.name,
        email: inputs.email,
        password: inputs.password,
      });

      // If the API call is successful, show success message
      if (response.success) {
        dispatch(
          showAlert({
            message: "Registration successful!",
            severity: "success",
          })
        );
        console.log(response,"res here")
         // Store user and token in local storage
      const storeUser =   Helper.localStorage.setItem("user", response.data.user);
      const storeToken =   Helper.localStorage.setItem("token", response.data.token);
      if (!storeUser.success && !storeToken.success) throw "Login Error: " + response.message


        // Dispatch success alert and navigate to homepage
        dispatch(showAlert({ message: response.message, severity: "success" }));
        navigate("/"); // Redirect to homepage
      } else {
        throw "Login Error: " + response.message;
      }

    } catch (error) {
      // Show error message if the API call fails
      dispatch(
        showAlert({
          message: error.message || "An unexpected error occurred",
          severity: "error",
        })
      );
      console.error("Login Error:", error);
    }
  };

  return (
    <Box component="form" sx={{ width: "100%" }}>
      <Typography sx={{ mb: 4 }} variant="h5" gutterBottom>
        Login to your account
      </Typography>
      <Input
        // Email address input field
        label="Email Address"
        required
        fullWidth
        name="email"
        value={inputs.email}
        onChange={(e) => handleChange("email", e.target.value)}
        key={"email"}
        sx={{ mb: 2 }}
      />
      <Input
        // Password input field
        label="Password"
        required
        fullWidth
        name="password"
        type="password"
        value={inputs.password}
        onChange={(e) => handleChange("password", e.target.value)}
        key={"password"}
        sx={{ mb: 2 }}
      />

      <Btn text="Login" onClick={handleSubmit} key={"btn"} />
      <ActionLinkBtn
        // Link to the signup page
        key={"register"}
        text="Not registered?"
        buttonText="Register"
        onClick={() => setPage("register")}
      />
    </Box>
  );
};
export default Login;

Login.propTypes = {
  setPage: PropTypes.func.isRequired,
};
