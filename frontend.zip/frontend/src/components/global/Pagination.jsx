import { Pagination, Stack } from '@mui/material';
import PropTypes from 'prop-types';

/**
 * A reusable Pagination component for handling page navigation.
 *
 * @component
 * @param {number} totalItems - Total number of items to paginate.
 * @param {number} itemsPerPage - Number of items per page.
 * @param {number} currentPage - The current active page.
 * @param {function} onPageChange - Callback function to handle the page change.
 */
const PaginationComponent = ({ totalItems, itemsPerPage, currentPage, onPageChange }) => {
  const pageCount = Math.ceil(totalItems / itemsPerPage);

  return (
    <Stack spacing={2} sx={{ mt: 4 }} alignItems="center">
      <Pagination
        count={pageCount}
        page={currentPage}
        onChange={(event, page) => onPageChange(page)} // Trigger the onPageChange callback
        color="primary"
      />
    </Stack>
  );
};

// PropTypes for the PaginationComponent to ensure proper usage
PaginationComponent.propTypes = {
  totalItems: PropTypes.number.isRequired,  // Total number of items
  itemsPerPage: PropTypes.number.isRequired, // Number of items per page
  currentPage: PropTypes.number.isRequired,  // The current page
  onPageChange: PropTypes.func.isRequired,   // Function to handle the page change
};

export default PaginationComponent;
