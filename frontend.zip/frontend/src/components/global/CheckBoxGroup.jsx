import { Checkbox, FormControlLabel, FormGroup } from "@mui/material";
import PropTypes from "prop-types";
/**
 * CheckboxGroup is a reusable component for rendering a group of checkboxes.
 * This component is used to avoid repeating similar logic for categories and sources.
 *
 * @component
 * @param {Array} items - The list of items (categories or sources) to render.
 * @param {Array} selectedItems - The currently selected items.
 * @param {function} onItemChange - The function to handle item selection change.
 */
const CheckboxGroup = ({ items, selectedItems, onItemChange }) => (
  <FormGroup>
    {items.map((item) => (
      <FormControlLabel
        key={item.id}
        control={
          <Checkbox
            checked={selectedItems.includes(item.id)}
            onChange={() => onItemChange(item.id)}
          />
        }
        label={item.label}
      />
    ))}
  </FormGroup>
);

export default CheckboxGroup;

// PropTypes for CheckboxGroup
CheckboxGroup.propTypes = {
  items: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
    })
  ).isRequired,
  selectedItems: PropTypes.array.isRequired,
  onItemChange: PropTypes.func.isRequired,
};
