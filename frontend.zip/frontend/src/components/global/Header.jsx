import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  IconButton,
} from "@mui/material";
import { Search } from "@mui/icons-material";
import PropTypes from "prop-types";
import { memo, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { useDispatch, useSelector } from "react-redux";
import CustomModal from "./Modal";
import FilterComponent from "./Filter";
import { filterData, handleFilterSubmit } from "../../utils/dummy";
import { closeModal, openModal } from "../../redux/slices/modalSlice";
import { Helper } from "../../utils/helper";
import { showAlert } from "../../redux/slices/alertSlice";

/**
 * ActionButton component for handling actions like logout, navigation, etc.
 *
 * @param {string} label - The button text.
 * @param {function} onClick - Function to handle button click.
 */
const ActionButton = ({ label, onClick }) => (
  <Button color="inherit" onClick={onClick}>
    {label}
  </Button>
);

// PropTypes for ActionButton
ActionButton.propTypes = {
  label: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
};

/**
 * Header component for the news aggregator project.
 *
 * This component provides a responsive header with navigation links and a search bar.
 *
 * @component
 */
const Header = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { isOpen } = useSelector((state) => state.modal);
  const [isLoggedIn, setIsLoggedIn] = useState(false);


  useEffect(() => {
    Helper.isUserLoggedIn() ? setIsLoggedIn(true) : setIsLoggedIn(false);
  }, []);

  const handleLogout = () => {
    // Remove token from localStorage
    const logout = Helper.logoutUser();
    console.log(logout);

    if (!logout.success) {

      return dispatch(
        showAlert({
          message: "Registration successful!",
          severity: "success",
        })
      );

    }
    setIsLoggedIn(false);
    showAlert({
      message: "Registration successful!",
      severity: "success",
    });

    // Redirect to the login page
    navigate("/auth");
  };

  const handleSearchClick = () => {
    dispatch(openModal()); // Open modal when search button is clicked
  };

  return (
    <AppBar position="static" sx={{ backgroundColor: "primary.main" }}>
      {/* Modal for filtering articles */}
      <CustomModal open={isOpen} handleClose={() => dispatch(closeModal())}>
        <FilterComponent
          filterData={filterData}
          onFilterSubmit={handleFilterSubmit}
        />
      </CustomModal>
      <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
        {/* Title / Logo on the left */}
        <Box sx={{ flexGrow: 1 }}>
          <Typography
            variant="h6"
            component="div"
            onClick={() => navigate("/")}
            sx={{ cursor: "pointer", width: "fit-content" }}
          >
            News Aggregator
          </Typography>
        </Box>

        {/* Search Bar and Action Button on the right */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            gap: 2,
            cursor: "unset",
          }}
        >
          {/* Logout Button with function call */}
          <ActionButton
            label="Articles"
            onClick={() => navigate("/articles")}
          />
          {/* Reusable Search Bar */}
          {/* <SearchBar
            keyword={keyword}
            onSearchChange={handleSearchChange}
            onSearchSubmit={handleSearchSubmit}
          /> */}
          <IconButton
            onClick={handleSearchClick}
            sx={{
              backgroundColor: "white",
              "&:hover": {
                backgroundColor: "primary.light", // Lighter shade of the primary color
                color: "white", // Change icon color on hover
              },
              transition: "background-color 0.3s ease, color 0.3s ease", // Smooth transitions
            }}
          >
            <Search />
          </IconButton>

          {/* Conditionally Render Login or Logout Button */}
          {isLoggedIn ? (
            <ActionButton label="LogOut" onClick={handleLogout} />
          ) : (
            <ActionButton label="Login" onClick={() => navigate("/auth")} />
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default memo(Header);
