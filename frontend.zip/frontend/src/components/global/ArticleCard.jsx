import { Card, CardContent, Typography, Box, Avatar } from "@mui/material";
import PropTypes from "prop-types";

/**
 * ArticleCard component that displays an individual article.
 * It includes the title, author, published date, and summary.
 *
 * @component
 * @param {Object} article - The article data.
 * @prop {string} article.image - The URL of the article image
 * @prop {string} article.title - The article title
 * @prop {string} article.author - The article author
 * @prop {string} article.date - The date the article was published
 */
const ArticleCard = ({ article }) => (
  <Card sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
    {/* Display the article image */}
    <Box
      component="img"
      src={article.image}
      alt={article.title}
      sx={{ height: 200, width: "100%", objectFit: "cover" }}
    />
    <CardContent sx={{ flexGrow: 1 }}>
      {/* Display the article title */}
      <Typography variant="h6" gutterBottom>
        {article.title}
      </Typography>
      {/* Display the article author and metadata */}
      <Box sx={{ display: "flex", alignItems: "center", mb: 1 }}>
        <Avatar sx={{ width: 24, height: 24 }} />
        <Typography variant="body2" color="textSecondary" sx={{ ml: 1 }}>
          {article.author}
        </Typography>
      </Box>
      {/* Display the article date */}
      <Typography variant="body2" color="textSecondary">
        Published: {article.date}
      </Typography>
    </CardContent>
  </Card>
);

ArticleCard.propTypes = {
  article: PropTypes.shape({
    image: PropTypes.string,
    title: PropTypes.string,
    author: PropTypes.string,
    date: PropTypes.string,
  }).isRequired,
};

export default ArticleCard;
