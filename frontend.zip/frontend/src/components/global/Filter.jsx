import { useState } from "react";
import { Box, Typography, Grid } from "@mui/material";
import PropTypes from "prop-types";
import Input from "./Input"; // Custom Input Component
import Btn from "./Button"; // Custom Button Component
import DateRangePickerComponent from "./DateRangePicker"; // New DateRangePicker Component
import CheckboxGroup from "./CheckBoxGroup";

/**
 * FilterComponent for filtering news by keyword, categories, sources, and date.
 *
 * This component follows SOLID, DRY, and KISS principles by using reusable functions and components.
 *
 * @component
 * @param {Object} filterData - The data for categories and sources.
 * @param {function} onFilterSubmit - Callback function to apply the selected filters.
 */
const FilterComponent = ({ filterData, onFilterSubmit }) => {
  const [keyword, setKeyword] = useState("");
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedSources, setSelectedSources] = useState([]);
  const [dateRange, setDateRange] = useState([null, null]);

  // Handle selection change for checkboxes
  const handleSelectionChange =
    (selectedItems, setSelectedItems) => (itemId) => {
      setSelectedItems((prevItems) =>
        prevItems.includes(itemId)
          ? prevItems.filter((id) => id !== itemId)
          : [...prevItems, itemId]
      );
    };

  // Handle filter submission
  const handleSubmit = () => {
    const filters = {
      keyword,
      categories: selectedCategories,
      sources: selectedSources,
      dateRange,
    };
    onFilterSubmit(filters); // Call the callback with selected filters
  };

  return (
    <Box sx={{ p: 4 }}>
      {/* Keyword Search */}
      <Typography variant="h6" gutterBottom>
        Search by Keyword
      </Typography>
      <Input
        label="Search news..."
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
        sx={{ mb: 3 }}
        size="small"
      />

      {/* Categories and Sources */}
      <Grid container spacing={2}>
        <Grid item xs={12} md={6}>
          <Typography variant="h6" gutterBottom>
            Categories
          </Typography>
          <CheckboxGroup
            items={Object.values(filterData.categories)}
            selectedItems={selectedCategories}
            onItemChange={handleSelectionChange(
              selectedCategories,
              setSelectedCategories
            )}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <Typography variant="h6" gutterBottom>
            Sources
          </Typography>
          <CheckboxGroup
            items={Object.values(filterData.sources)}
            selectedItems={selectedSources}
            onItemChange={handleSelectionChange(
              selectedSources,
              setSelectedSources
            )}
          />
        </Grid>
      </Grid>

      {/* Date Range Picker (Reused) */}
      <DateRangePickerComponent
        dateRange={dateRange}
        setDateRange={setDateRange}
      />

      {/* Submit Button */}
      <Box display="flex" justifyContent="center" mt={4}>
        <Btn
          text="Apply Filters"
          onClick={handleSubmit}
          fullWidth={false}
          sx={{ minWidth: 150 }}
        />
      </Box>
    </Box>
  );
};

// PropTypes for FilterComponent
FilterComponent.propTypes = {
  filterData: PropTypes.shape({
    categories: PropTypes.object.isRequired,
    sources: PropTypes.object.isRequired,
  }).isRequired,
  onFilterSubmit: PropTypes.func.isRequired,
};

export default FilterComponent;
