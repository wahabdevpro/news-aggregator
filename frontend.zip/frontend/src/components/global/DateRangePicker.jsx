import { Box, Typography } from "@mui/material";
import { DateRangePicker } from "@mui/x-date-pickers-pro";
import { LocalizationProvider } from "@mui/x-date-pickers-pro/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers-pro/AdapterDayjs";
import PropTypes from "prop-types";
import Input from "./Input"; // Custom Input Component

/**
 * DateRangePickerComponent allows users to select a date range.
 * This component is reusable and can be used across different forms.
 *
 * @component
 * @param {Array} dateRange - The current selected date range [startDate, endDate].
 * @param {function} setDateRange - Function to update the selected date range.
 * @returns {JSX.Element} - The DateRangePickerComponent.
 */
const DateRangePickerComponent = ({ dateRange, setDateRange }) => {
  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box sx={{ mt: 3 }}>
        <Typography variant="h6" gutterBottom>
          Filter by Date
        </Typography>
        <DateRangePicker
          startText="Start Date"
          endText="End Date"
          disableFuture={true}
          value={dateRange}
          onChange={(newValue) => setDateRange(newValue)}
          renderInput={(startProps, endProps) => (
            <>
              <Input {...startProps} label="Start Date" sx={{ mr: 2 }} size="small" />
              <Input {...endProps} label="End Date" size="small" />
            </>
          )}
        />
      </Box>
    </LocalizationProvider>
  );
};

// PropTypes for DateRangePickerComponent
DateRangePickerComponent.propTypes = {
  dateRange: PropTypes.array.isRequired, // Date range [startDate, endDate]
  setDateRange: PropTypes.func.isRequired, // Function to update date range
};

export default DateRangePickerComponent;
