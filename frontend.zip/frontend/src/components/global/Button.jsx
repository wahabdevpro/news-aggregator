import { Button, CircularProgress } from "@mui/material";
import PropTypes from "prop-types";

/**
 * A customizable button component that supports loading states.
 *
 * This component renders a MUI Button with an optional loading spinner
 * when `isLoading` is true. It supports various customization options
 * such as color, variant, and full-width styling.
 *
 * @component
 * @param {string} text - The text to display inside the button.
 * @param {function} onClick - Function to handle the button click event.
 * @param {string} color - Button color (default: "primary").
 * @param {boolean} fullWidth - Whether the button should take the full width of its container.
 * @param {string} variant - Button variant (default: "contained").
 * @param {object} sx - MUI sx style object for custom styling.
 * @param {boolean} isLoading - Whether the button should show a loading spinner.
 * @param {string} type - Button type (default: "button").
 * @returns {JSX.Element} - The rendered button component.
 */
const Btn = ({
  text,
  onClick,
  color = "primary",
  fullWidth = true,
  variant = "contained",
  sx = {},
  isLoading = false,
  type = "button",
}) => (
  <Button
    onClick={onClick}
    type={type}
    color={color}
    fullWidth={fullWidth}
    variant={variant}
    sx={sx}
    disabled={isLoading} // Disable button during loading state
  >
    {isLoading ? <CircularProgress size={24} /> : text}
  </Button>
);

Btn.propTypes = {
  text: PropTypes.string.isRequired,
  onClick: PropTypes.func,
  color: PropTypes.oneOf(["primary", "secondary", "inherit", "default"]),
  fullWidth: PropTypes.bool,
  variant: PropTypes.oneOf(["contained", "outlined", "text"]),
  sx: PropTypes.object,
  isLoading: PropTypes.bool,
  type: PropTypes.oneOf(["button", "submit", "reset"]),
};

export default Btn;
